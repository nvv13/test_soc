#!/bin/sh
# ©2020 WifiRadio.su
uci set wifiradio.@setting[0].playpause=play
uci commit wifiradio 

mpc stop