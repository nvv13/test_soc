#!/bin/sh  
# ©2020 WifiRadio.su

while (true) 
do

rpt=$(uci get wifiradio.@setting[0].rpt)
let rpt=$rpt*60

 sleep $rpt;
 
playpause=$(uci get wifiradio.@setting[0].playpause)

if [[ $playpause == "stop" ]]
then

mac=`ifconfig | head -1 | sed 's/ \+/ /g' | cut -d' ' -f5`
sleep 1
station=$(uci get wifiradio.@setting[0].station)
server=$(uci get wifiradio.@setting[0].server)
time=$(uci get wifiradio.@setting[0].time)
wheater=$(uci get wifiradio.@setting[0].wheater)
hello=$(uci get wifiradio.@setting[0].hello)
tts=$(uci get wifiradio.@setting[0].tts)
city=$(uci get wifiradio.@setting[0].city)

if [ $time -eq 1 ]
then
utcz=`cat /etc/TZ`
len=`expr length $utcz`
utcz=`expr substr $utcz $len 1`
curl "$server/time.php?utcz=$utcz&tts=$tts&mac=$mac"
sleep 3
fi

hello=${hello// /_}
if [ $hello != "_" ]
then
curl "$server/hello.php?hello=$hello&tts=$tts&mac=$mac"
sleep 3
fi

if [ $wheater -eq 1 ]
then
city=${city//_/}
city=${city// /%20}
curl "$server/wheater.php?city=$city&mac=$mac&tts=$tts"
sleep 3
fi

mpc stop
mpc clear
mpc repeat off

hello=${hello// /_}
if [ $hello != "_" ]
then
mpc add "$server/tts.hello/"$mac"_hello.mp3"
fi

if [ $time -eq 1 ]
then
mpc add "$server/tts.wtime/"$mac"_time.mp3"
fi

if [ $wheater -eq 1 ]
then
mpc add "$server/tts.wtime/"$mac"_wheater.mp3"
fi

mpc play 1

    mpc | grep playing
    while [ $? -eq 0 ]
    do
	    sleep 2
	    mpc | grep playing
    done
	
/etc/wifiradio/play.sh

fi

done;
