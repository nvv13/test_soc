#!/bin/sh
# ©2020 WifiRadio.su
png=$(uci get wifiradio.@setting[0].ping)

if [ $png -eq 1 ]
then
while true; do
sleep 10
if ! ping -q -c 2 -W 4 8.8.8.8 > /dev/null; then
sleep 5

playpause=$(uci get wifiradio.@setting[0].playpause)

if [[ $playpause == "stop" ]]
then

mpc stop

cur=$(uci get wifiradio.@setting[0].current) 

station=$cur

mpc stop
mpc play 2

fi

fi
done
fi
