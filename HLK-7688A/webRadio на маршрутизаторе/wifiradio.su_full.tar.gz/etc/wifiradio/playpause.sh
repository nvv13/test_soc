#!/bin/sh
# ©2020 WifiRadio.su
playpause=$(uci get wifiradio.@setting[0].playpause)

if [[ $playpause == "play" ]]
then
/etc/wifiradio/play.sh
fi

if [[ $playpause == "stop" ]]
then
/etc/wifiradio/stop.sh
fi
