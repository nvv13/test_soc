#!/bin/sh
# ©2019 WifiRadio.su  
killall curl
killall madplay