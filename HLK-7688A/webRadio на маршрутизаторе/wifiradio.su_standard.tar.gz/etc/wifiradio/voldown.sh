#!/bin/sh  
# ©2018 WifiRadio.su

sound=$(uci get wifiradio.@setting[0].sound)
amixer -q set $sound 5%-