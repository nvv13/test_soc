#!/bin/sh  
# ©2020 WifiRadio.su 
ver=$(uci get wifiradio.@setting[0].version_loc)
server=$(uci get wifiradio.@setting[0].server)
mac=`ifconfig | head -1 | sed 's/ \+/ /g' | cut -d' ' -f5`
sound=$(uci get wifiradio.@setting[0].sound)
tts=$(uci get wifiradio.@setting[0].tts)
 
while true; do
pl=/etc/wifiradio/playlist.m3u
cur=$(uci get wifiradio.@setting[0].current)
curnm=$(($cur - 1))
voices=$(($cur / 2))
name=$(head -n $curnm $pl | tail -n 1 | cut -c 12-)
st=$(head -n $cur $pl | tail -n 1)

name=${name// /_}
link=$st

voice=$(uci get wifiradio.@setting[0].voice)
pfp=$(uci get wifiradio.@setting[0].pfp)
tts=$(uci get wifiradio.@setting[0].tts)
city=$(uci get wifiradio.@setting[0].city)
city=${city//_/}
city=${city// /%20}

uci set wifiradio.@setting[0].station="$name"
uci set wifiradio.@setting[0].station_url="$st"
uci commit wifiradio

if [ $pfp -eq 0 ]
then
if [ $voice -eq 1 ]
then

usr=$((0))
while read line
do
usr=$(($usr+1))
done < /etc/wifiradio/user.m3u

if [ $cur -le $usr ]
then
curl "$server/voice_.php?ver=$ver.Standard&station=$name&tts=$tts&mac=$mac&city=$city&link=$link"
sleep 1
amixer -q set $sound 10%+
curl -A "WifiRadio.SU" "$server/tts.voice/$tts.$name.mp3" | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
amixer -q set $sound 10%-
else
amixer -q set $sound 10%+
curl -A "WifiRadio.SU" "$server/tts.voice/$tts.$name.mp3" | madplay --replay-gain=audiophile --attenuate=-0 --stereo -
amixer -q set $sound 10%-
fi

fi
fi

curl -A "WifiRadio.SU/$ver.Standard" $st 2>/dev/null| madplay --replay-gain=audiophile --attenuate=-0 --stereo -
done
